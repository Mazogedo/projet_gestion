<?php


//Ouverture d'une connexion a la base de donnees
$objetPdo = new PDO('mysql:host=localhost;dbname=projet','root','root');


//Preparation d'ue requete d'insertion

$Pdostat=$objetPdo->prepare('INSERT INTO admin VALUES(:id,:nom,:email,:genre,:contact,:passe,:hash)');

//On lie chaque marqueur a une valeur

$Pdostat->bindValue(':id',null, PDO::PARAM_STR);
$Pdostat->bindValue(':nom',$_POST['name'], PDO::PARAM_STR);
$Pdostat->bindValue(':email',$_POST['email'], PDO::PARAM_STR);
$Pdostat->bindValue(':genre',$_POST['genre'], PDO::PARAM_STR);
$Pdostat->bindValue(':contact',$_POST['contact'], PDO::PARAM_STR);
$Pdostat->bindValue(':passe',$_POST['passe'], PDO::PARAM_STR);
$Pdostat->bindValue(':hash',$_POST['pass'], PDO::PARAM_STR);


//Execution de la requete preparee
$insertsoK=$Pdostat->execute();

if ($insertsoK)
{
echo "enregistrements effectuees" ;
} 
else
{
echo	"enregistrements effectuees";
}
?>


