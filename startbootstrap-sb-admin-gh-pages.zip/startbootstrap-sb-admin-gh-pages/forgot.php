<?php


if ( ! empty($_POST['email']) && ! empty($_POST['contact']) ) 
{

    $objetPdo = new PDO('mysql:host=localhost;dbname=projet_igs', 'root', 'root');
    
    $Pdostat = $objetPdo->prepare('SELECT * FROM admin where email=:email AND contact=:contact');

   
   $Pdostat->execute(array('email' => $_POST['email'], 'contact' => $_POST['contact']));

    $free = $Pdostat -> rowCount();
             


    if ($free == 1 ) 
    {
        $vue =  $Pdostat -> fetchAll() ;

        foreach ($vue as $val) {
            
         
        }
    } 
    else {
     echo 'mot de passe ou email incorrect'.header("location:password.html");
    }

} 
else {
    echo 'Veuillez entrer vos donnees'.header("location:password.html");
}



?>
<body style="background-color:blue;">
<a style="color:red;font-size:xx-large;" href="index.php"> <--retour </a>

<h1 align="center" style="color:white;font-size:xx-large;"> VOTRE MOT DE PASSE EST  : <?php echo $val['passe']  ; ?> </h1>

</body>