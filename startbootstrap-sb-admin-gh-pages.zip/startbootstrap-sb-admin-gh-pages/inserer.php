<?php
session_start();

                                    
                                    $objetPdo = new PDO('mysql:host=localhost;dbname=boss','root','root');
                                                                
                                                                
                                    //Preparation d'ue requete d'insertion
                                    
                                    $Pdostat=$objetPdo->prepare('SELECT * FROM produit where reference =:reference ');
                                    
                                    
                                    $Pdostat -> execute(array('reference'=> $_GET['id'] ));
                                    
                                    $var = $Pdostat -> fetchAll();
                                    
                                    foreach ($var as $val) 
                                    {
                                        
                                     $lib = $val['libelle'] ;
                                      $min  = $val['qte_min'] ;
                                     $stock = $val['qte_stock'] ;

                                    }
                                 
                                    
 
                                    ?>