

<!DOCTYPE html>





<?php

if ( ! empty($_POST['name']) && ! empty($_POST['email']) && ! empty($_POST['passe']) && ! empty($_POST['genre']) && ! empty($_POST['pass']) && ! empty($_POST['contact']) )
{
//connexion a al base de donnees
    if ( $_POST['passe'] = $_POST['pass'] ) 

        {
  
        $hash = sha1($_POST['passe'] );

        //Ouverture d'une connexion a la base de donnees
        $objetPdo = new PDO('mysql:host=localhost;dbname=animal','root','root');
        
        
        //Preparation d'ue requete d'insertion
        
        $Pdostat=$objetPdo->prepare('INSERT INTO admin VALUES(:id,:nom,:email,:genre,:contact,:passe,:hash)');
        
        //On lie chaque marqueur a une valeur
        
        $Pdostat->bindValue(':id',null, PDO::PARAM_STR);
        $Pdostat->bindValue(':nom',$_POST['name'], PDO::PARAM_STR);
        $Pdostat->bindValue(':email',$_POST['email'], PDO::PARAM_STR);
         $Pdostat->bindValue(':genre',$_POST['genre'], PDO::PARAM_STR);
         $Pdostat->bindValue(':contact',$_POST['contact'], PDO::PARAM_STR);
         $Pdostat->bindValue(':passe',$_POST['passe'], PDO::PARAM_STR);
        $Pdostat->bindValue(':hash',$hash, PDO::PARAM_STR);
        
        
        
        //Execution de la requete preparee
        $Test=$Pdostat->execute();
    

        if ($Test) {
                echo 'data saved'.header('location:index.php');
            } else {
            echo ' <script type="text/javascript"> alert("inscription non reuissi")  </script> '.'<a style="font-size:xx-large;color:red;"  href="inscriptiom.php">  <--retour  </a>'; 
            }




        } 
        else
        {
           echo '<script > alert(" les deux mots de passe different ") </script> ';
        }

}
else
{
 echo ' <script > alert(" remplir tous les champs svp") </script> '.'<a style="font-size:xx-large;color:red;" href="inscriptiom.php">  <--retour </a>';
}




?> 