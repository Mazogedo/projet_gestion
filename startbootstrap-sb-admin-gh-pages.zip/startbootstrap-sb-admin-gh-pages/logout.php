<?php
if (session_destroy()) {
    echo '<script > alert(" vous etes deconnectez ") </script>'. header("location:login.html");
} else {
    echo  '<script > alert(" impossible de vous deconnectez  ") </script>'. header("location:dashbord.php");
}
?>