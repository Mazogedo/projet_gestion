<?php





require_once 'inserer.php' ;

$_SESSION['id'] = $_GET['id'] ;
?>



<form method="post" action="modifier2.php">
    <kbd>   formulaire de modification </kbd> 
    
<div class="container" style="border:1px black solid;" >

        <div align="center" style="display:grid;grid-template-columns: 5% 90% 5% ;
        grid-template-rows:100% ;">
        <!--5%-->
            <div >
            
            </div >

            <!--90%-->
            <div >
            <input type="text"  placeholder="reference du produit" name="lib" size="20" value=" <?php echo $lib ; ?> ">
            </div >

            <!--5%-->
            <div >
            
            </div>
            
        </div> 

        <div align="center" style="display:grid;grid-template-columns: 5% 45%  45% 5% ;
        grid-template-rows:100% ;">
        <!--5%-->
            <div >
        
            </div >
            <!--45%-->
            <div >

            <input  type="text" style=""  placeholder="quantite minimale "  name="min" size="=20" value=" <?php echo $min ; ?> ">
            </div >
            <!--45%-->
            <div >

            <input type="text" placeholder="quantite en stock " name="stock" size="20" value=" <?php echo $stock ; ?> ">
            </div >
            <!--5%-->_
            <div >
            
            </div>
    
        </div>    <br>

    <div align="center" > <input style="background-color:blue;color:white;width:30%;"  type="submit" value="MODIFIER" > </div> <br>
    <div align="center" > <input style="background-color:red;color:white;width:30%;" type="reset" value="ANNULER" > </div>

</div>
</form>


