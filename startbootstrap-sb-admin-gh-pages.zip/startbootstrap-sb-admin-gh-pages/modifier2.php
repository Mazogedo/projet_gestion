<?php
session_start();


if ( ! empty($_POST['lib']) && ! empty($_POST['stock']) && ! empty($_POST['min']) ) 
{


                                    
                                    $objetPdo = new PDO('mysql:host=localhost;dbname=boss','root','root');
                                                                
                                                                
                                    //Preparation d'ue requete d'insertion
                                    
                                    $Pdostat=$objetPdo->prepare('UPDATE produit SET libelle=:libelle , qte_stock =:qte_stock , qte_min=:qte_min WHERE reference=:reference ');
                                    
                                    
                                   $free = $Pdostat -> execute(array('libelle'=> $_POST['lib'],'qte_stock'=> $_POST['stock'],'qte_min'=>$_POST['min'],'reference'=> $_SESSION['id'] ));
                                    
                                    
                                    if ($free ) 
                                    {
                                        echo 'Donnees modifiees'.header('location:dashbord.php');
                                    } else 
                                    {
                                     echo 'Donnees non modifiees'.header('location:modifier.php');
                                    }
                                
                                } 
                                else {
                                    echo 'Veuillez entrer tous les champs'.header('location:modifier.php');
                                }
                                
                                   