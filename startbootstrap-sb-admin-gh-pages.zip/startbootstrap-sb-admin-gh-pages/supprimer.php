<?php

session_start();



    $objetPdo = new PDO('mysql:host=localhost;dbname=boss', 'root', 'root');
    
    $Pdostat = $objetPdo->prepare('DELETE FROM produit where reference=:reference');

   

    $free = $Pdostat->execute(array('reference'=>$_GET['id']));

 
             
    if ($free ) {
        echo 'donnees supprimees '.header('location:dashbord.php');
    } else {
     echo 'donnees non supprimees '.header('location:dashbord.php');
    }


?>