<?php

session_start();


if ( ! empty($_POST['email']) && ! empty($_POST['passe']) ) 
{
    $hash = sha1($_POST['passe'] );

    $objetPdo = new PDO('mysql:host=localhost;dbname=boss', 'root', 'root');
    
    $Pdostat = $objetPdo->prepare('SELECT * FROM admin where email=:email AND hash=:hash');

   

     $Pdostat->execute(array('email'=>$_POST['email'],'hash'=>$hash));

     $vue =  $Pdostat -> fetchAll() ;

        foreach ($vue as $val) 
{

                    $_SESSION['nom']  = $val['nom'] ;
}
                    $free = $Pdostat -> RowCount();

             
    if ($free == 1) {
        echo 'data saved'.header('location:dashbord.php');
    } else {
     echo 'mot de passe ou email incorrect'.header('location:index.php');
    }

} 
else {
    echo 'Veuillez entrer vos donnees'.header('location:index.php');
}



?>